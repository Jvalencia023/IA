# Divina Providencia · MVP

## 1. Backend (FastAPI + PostgreSQL)
```bash
cd backend
docker compose up -d                     # PostgreSQL
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload            # Swagger: http://localhost:8000/docs
```
Luego importa `backend/plantilla_inventario.csv` desde el panel web o desde Swagger
(`POST /api/v1/inventario/importar-excel`).

## 2. Panel web
```bash
cd web && cp .env.example .env && npm install && npm run dev   # http://localhost:5173
```

## 3. App móvil
```bash
cd mobile && npm install && npx expo start
```
Edita `mobile/config.js` con la IP del servidor.
