from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, Field


class VarianteOut(BaseModel):
    variante_id: int
    color: str
    talla: str
    stock_disponible: int


class ProductoOut(BaseModel):
    id: int
    referencia: str
    nombre: str
    categoria: str
    precio_base: Decimal


class ItemPedidoIn(BaseModel):
    variante_id: int
    cantidad: int = Field(gt=0)


class PedidoIn(BaseModel):
    cliente_nombre: str = Field(min_length=1, max_length=150)
    vendedor_id: int
    items: list[ItemPedidoIn] = Field(min_length=1)


class DetalleOut(BaseModel):
    variante_id: int
    referencia: str
    nombre: str
    color: str
    talla: str
    cantidad: int
    precio_unitario: Decimal


class PedidoOut(BaseModel):
    id: int
    cliente_nombre: str
    vendedor_id: int
    estado: str
    total_pedido: Decimal
    creado_en: datetime
    detalles: list[DetalleOut]


class EstadoIn(BaseModel):
    estado: str  # "Despachado" | "Cancelado"


class KardexRow(BaseModel):
    variante_id: int
    referencia: str
    nombre: str
    categoria: str
    color: str
    talla: str
    stock_actual: int
    estado: str  # Disponible | Stock Bajo | Agotado
