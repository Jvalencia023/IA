from datetime import datetime
from decimal import Decimal

from sqlalchemy import (CheckConstraint, DateTime, ForeignKey, Integer, Numeric,
                        String, UniqueConstraint, func)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

ESTADOS_PEDIDO = ("Pendiente", "Despachado", "Cancelado")


class Base(DeclarativeBase):
    pass


class Producto(Base):
    __tablename__ = "productos"

    id: Mapped[int] = mapped_column(primary_key=True)
    referencia: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    nombre: Mapped[str] = mapped_column(String(150))
    categoria: Mapped[str] = mapped_column(String(80))
    precio_base: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    variantes: Mapped[list["VarianteProducto"]] = relationship(back_populates="producto")


class VarianteProducto(Base):
    __tablename__ = "variantes_producto"
    __table_args__ = (UniqueConstraint("producto_id", "color", "talla", name="uq_variante"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    producto_id: Mapped[int] = mapped_column(ForeignKey("productos.id"), index=True)
    color: Mapped[str] = mapped_column(String(60))
    talla: Mapped[str] = mapped_column(String(20))

    producto: Mapped[Producto] = relationship(back_populates="variantes")
    inventario: Mapped["Inventario"] = relationship(back_populates="variante", uselist=False)


class Inventario(Base):
    __tablename__ = "inventario"
    __table_args__ = (CheckConstraint("stock_actual >= 0", name="ck_stock_no_negativo"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    variante_id: Mapped[int] = mapped_column(ForeignKey("variantes_producto.id"), unique=True)
    stock_actual: Mapped[int] = mapped_column(Integer, default=0)
    actualizado_en: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    variante: Mapped[VarianteProducto] = relationship(back_populates="inventario")


class Pedido(Base):
    __tablename__ = "pedidos"
    __table_args__ = (
        CheckConstraint("estado IN ('Pendiente','Despachado','Cancelado')", name="ck_estado"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    cliente_nombre: Mapped[str] = mapped_column(String(150))
    vendedor_id: Mapped[int] = mapped_column(Integer, index=True)
    estado: Mapped[str] = mapped_column(String(20), default="Pendiente", index=True)
    total_pedido: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    detalles: Mapped[list["DetallePedido"]] = relationship(back_populates="pedido")


class DetallePedido(Base):
    __tablename__ = "detalles_pedido"
    __table_args__ = (CheckConstraint("cantidad > 0", name="ck_cantidad_positiva"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    pedido_id: Mapped[int] = mapped_column(ForeignKey("pedidos.id"), index=True)
    variante_id: Mapped[int] = mapped_column(ForeignKey("variantes_producto.id"))
    cantidad: Mapped[int] = mapped_column(Integer)
    precio_unitario: Mapped[Decimal] = mapped_column(Numeric(12, 2))

    pedido: Mapped[Pedido] = relationship(back_populates="detalles")
    variante: Mapped[VarianteProducto] = relationship()
