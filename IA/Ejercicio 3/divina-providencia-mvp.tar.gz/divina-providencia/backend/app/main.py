from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .database import engine
from .models import Base
from .routers import inventario, pedidos, productos


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)  # MVP; en producción usar Alembic
    yield


app = FastAPI(title="Divina Providencia API", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins.split(","),
                   allow_methods=["*"], allow_headers=["*"])
app.include_router(productos.router)
app.include_router(pedidos.router)
app.include_router(inventario.router)


@app.get("/health")
def health():
    return {"ok": True}
