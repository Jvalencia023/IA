from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Inventario, Producto, VarianteProducto


def aplicar(db: Session, filas: list[dict], modo: str = "reemplazar") -> dict:
    """Upsert de productos/variantes/inventario. Todo o nada: el commit lo hace el router."""
    productos: dict[str, Producto] = {
        p.referencia: p for p in db.scalars(select(Producto)).all()}
    resumen = {"productos_creados": 0, "variantes_creadas": 0, "variantes_actualizadas": 0}

    for f in filas:
        p = productos.get(f["referencia"])
        if p is None:
            p = Producto(referencia=f["referencia"], nombre=f["nombre_producto"],
                         categoria=f["categoria"], precio_base=f["precio_base"])
            db.add(p)
            db.flush()
            productos[p.referencia] = p
            resumen["productos_creados"] += 1
        else:
            p.nombre, p.categoria, p.precio_base = (
                f["nombre_producto"], f["categoria"], f["precio_base"])

        v = db.scalar(select(VarianteProducto).where(
            VarianteProducto.producto_id == p.id,
            VarianteProducto.color == f["color"], VarianteProducto.talla == f["talla"]))
        if v is None:
            v = VarianteProducto(producto_id=p.id, color=f["color"], talla=f["talla"])
            db.add(v)
            db.flush()
            db.add(Inventario(variante_id=v.id, stock_actual=f["stock_inicial"]))
            resumen["variantes_creadas"] += 1
        else:
            inv = db.scalar(select(Inventario).where(
                Inventario.variante_id == v.id).with_for_update())
            inv.stock_actual = (f["stock_inicial"] if modo == "reemplazar"
                                else inv.stock_actual + f["stock_inicial"])
            resumen["variantes_actualizadas"] += 1
    return resumen
