"""Lectura y validación del archivo de carga masiva. Solo depende de pandas (sin BD)."""
import io
import re
from decimal import Decimal, InvalidOperation

import pandas as pd

COLUMNAS = ["referencia", "nombre_producto", "categoria", "precio_base",
            "color", "talla", "stock_inicial"]


class ArchivoInvalido(Exception):
    """Archivo ilegible o sin las columnas obligatorias."""


def leer_archivo(contenido: bytes, nombre: str) -> pd.DataFrame:
    nombre = (nombre or "").lower()
    try:
        if nombre.endswith(".csv"):
            texto = None
            for enc in ("utf-8-sig", "latin-1"):  # Excel en español suele guardar en latin-1
                try:
                    texto = contenido.decode(enc)
                    break
                except UnicodeDecodeError:
                    continue
            # sep=None detecta coma o punto y coma (Excel en español usa ';')
            df = pd.read_csv(io.StringIO(texto), sep=None, engine="python",
                             dtype=str, keep_default_na=False)
        elif nombre.endswith(".xlsx"):
            df = pd.read_excel(io.BytesIO(contenido), dtype=str, keep_default_na=False,
                               engine="openpyxl")
        else:
            raise ArchivoInvalido("Formato no soportado. Sube un archivo .csv o .xlsx.")
    except ArchivoInvalido:
        raise
    except Exception as e:
        raise ArchivoInvalido(f"No se pudo leer el archivo: {e}")

    df.columns = [str(c).strip().lower() for c in df.columns]
    faltan = [c for c in COLUMNAS if c not in df.columns]
    if faltan:
        raise ArchivoInvalido(f"Faltan columnas obligatorias: {', '.join(faltan)}")
    return df[COLUMNAS]


def _precio(valor: str) -> Decimal:
    v = valor.replace("$", "").replace(" ", "")
    if re.fullmatch(r"\d{1,3}(\.\d{3})+", v):  # 45.000 -> 45000 (formato colombiano)
        v = v.replace(".", "")
    elif "," in v and "." not in v:
        v = v.replace(",", ".")
    return Decimal(v)


def validar(df: pd.DataFrame) -> tuple[list[dict], list[dict]]:
    """Devuelve (filas_limpias, errores). La fila 1 del archivo es el encabezado,
    por eso los datos empiezan en la fila 2 (igual que en Excel)."""
    errores: list[dict] = []
    limpias: list[dict] = []
    vistos: dict[tuple, int] = {}
    por_ref: dict[str, tuple] = {}

    def err(fila, columna, msg):
        errores.append({"fila": fila, "columna": columna, "error": msg})

    for i, r in enumerate(df.to_dict("records")):
        fila = i + 2
        if all(str(v).strip() == "" for v in r.values()):
            continue  # fila totalmente vacía
        n = len(errores)
        v = {k: str(x).strip() for k, x in r.items()}

        for c in ("referencia", "nombre_producto", "categoria", "color", "talla"):
            if not v[c]:
                err(fila, c, "Campo obligatorio vacío")
        v["referencia"] = v["referencia"].upper()

        try:
            v["precio_base"] = _precio(v["precio_base"])
            if v["precio_base"] <= 0:
                err(fila, "precio_base", "Debe ser mayor que 0")
        except (InvalidOperation, ValueError):
            err(fila, "precio_base", f"'{r['precio_base']}' no es un número válido")

        try:
            stock = Decimal(v["stock_inicial"])
            if stock != stock.to_integral_value() or stock < 0:
                raise ValueError
            v["stock_inicial"] = int(stock)
        except (InvalidOperation, ValueError):
            err(fila, "stock_inicial", f"'{r['stock_inicial']}' debe ser un entero >= 0")

        if len(errores) == n:  # chequeos cruzados solo si la fila es válida
            llave = (v["referencia"], v["color"].lower(), v["talla"].lower())
            if llave in vistos:
                err(fila, "referencia/color/talla",
                    f"Variante duplicada (ya aparece en la fila {vistos[llave]})")
            else:
                vistos[llave] = fila
            base = (v["nombre_producto"], v["categoria"], v["precio_base"])
            if v["referencia"] in por_ref and por_ref[v["referencia"]][0] != base:
                err(fila, "referencia",
                    f"Datos del producto distintos a los de la fila {por_ref[v['referencia']][1]} "
                    "(nombre, categoría o precio)")
            por_ref.setdefault(v["referencia"], (base, fila))

        if len(errores) == n:
            limpias.append(v)
    return limpias, errores
