from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..models import DetallePedido, Inventario, Pedido, VarianteProducto
from ..schemas import DetalleOut, EstadoIn, PedidoIn, PedidoOut

router = APIRouter(prefix="/api/v1/pedidos", tags=["Pedidos"])


def _out(p: Pedido) -> PedidoOut:
    return PedidoOut(
        id=p.id, cliente_nombre=p.cliente_nombre, vendedor_id=p.vendedor_id,
        estado=p.estado, total_pedido=p.total_pedido, creado_en=p.creado_en,
        detalles=[DetalleOut(
            variante_id=d.variante_id, referencia=d.variante.producto.referencia,
            nombre=d.variante.producto.nombre, color=d.variante.color,
            talla=d.variante.talla, cantidad=d.cantidad,
            precio_unitario=d.precio_unitario) for d in p.detalles])


@router.post("", response_model=PedidoOut, status_code=201)
def crear_pedido(payload: PedidoIn, db: Session = Depends(get_db)):
    """Transacción atómica con bloqueo de fila. Si algo no alcanza, se rechaza TODO (400)."""
    # Si la misma variante llega dos veces, se suman antes de validar.
    pedidas: dict[int, int] = {}
    for it in payload.items:
        pedidas[it.variante_id] = pedidas.get(it.variante_id, 0) + it.cantidad
    ids = sorted(pedidas)  # orden fijo de bloqueo => evita deadlocks entre pedidos concurrentes

    try:
        inventarios = {i.variante_id: i for i in db.scalars(
            select(Inventario).where(Inventario.variante_id.in_(ids))
            .order_by(Inventario.variante_id).with_for_update()).all()}

        problemas = []
        for vid in ids:
            inv = inventarios.get(vid)
            if inv is None:
                problemas.append({"variante_id": vid, "error": "Variante no existe"})
            elif inv.stock_actual < pedidas[vid]:
                problemas.append({"variante_id": vid, "solicitado": pedidas[vid],
                                  "disponible": inv.stock_actual,
                                  "error": "Stock insuficiente"})
        if problemas:
            db.rollback()
            raise HTTPException(400, {"mensaje": "Pedido rechazado", "detalle": problemas})

        variantes = {v.id: v for v in db.scalars(
            select(VarianteProducto).options(joinedload(VarianteProducto.producto))
            .where(VarianteProducto.id.in_(ids))).all()}

        pedido = Pedido(cliente_nombre=payload.cliente_nombre.strip(),
                        vendedor_id=payload.vendedor_id, estado="Pendiente",
                        total_pedido=Decimal(0))
        db.add(pedido)
        total = Decimal(0)
        for vid in ids:
            precio = variantes[vid].producto.precio_base  # se congela el precio al vender
            inventarios[vid].stock_actual -= pedidas[vid]
            total += precio * pedidas[vid]
            pedido.detalles.append(DetallePedido(
                variante_id=vid, cantidad=pedidas[vid], precio_unitario=precio))
        pedido.total_pedido = total
        db.commit()
    except HTTPException:
        raise
    except Exception:
        db.rollback()
        raise

    return _out(_cargar(db, pedido.id))


def _cargar(db: Session, pedido_id: int) -> Pedido:
    return db.scalars(select(Pedido).options(
        joinedload(Pedido.detalles).joinedload(DetallePedido.variante)
        .joinedload(VarianteProducto.producto)).where(Pedido.id == pedido_id)).unique().one()


@router.get("", response_model=list[PedidoOut])
def listar_pedidos(estado: str | None = Query(None), db: Session = Depends(get_db)):
    """(Adicional) Alimenta las pestañas Pendientes / Despachados del panel web."""
    q = select(Pedido).options(joinedload(Pedido.detalles).joinedload(DetallePedido.variante)
                               .joinedload(VarianteProducto.producto)
                               ).order_by(Pedido.creado_en.desc())
    if estado:
        q = q.where(Pedido.estado == estado)
    return [_out(p) for p in db.scalars(q).unique().all()]


@router.patch("/{pedido_id}/estado", response_model=PedidoOut)
def cambiar_estado(pedido_id: int, body: EstadoIn, db: Session = Depends(get_db)):
    """(Adicional) Despachar o cancelar. Cancelar un Pendiente devuelve el stock."""
    if body.estado not in ("Despachado", "Cancelado"):
        raise HTTPException(400, "Estado inválido: use 'Despachado' o 'Cancelado'")
    try:
        p = db.scalars(select(Pedido).where(Pedido.id == pedido_id).with_for_update()).one_or_none()
        if p is None:
            raise HTTPException(404, "Pedido no encontrado")
        if p.estado != "Pendiente":
            raise HTTPException(409, f"El pedido ya está {p.estado}")
        if body.estado == "Cancelado":
            for d in sorted(p.detalles, key=lambda x: x.variante_id):
                inv = db.scalars(select(Inventario).where(
                    Inventario.variante_id == d.variante_id).with_for_update()).one()
                inv.stock_actual += d.cantidad
        p.estado = body.estado
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    except Exception:
        db.rollback()
        raise
    return _out(_cargar(db, pedido_id))
