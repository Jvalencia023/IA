from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..models import Inventario, Producto, VarianteProducto
from ..schemas import KardexRow
from ..services import importador, validacion

router = APIRouter(prefix="/api/v1/inventario", tags=["Inventario"])


def _estado(stock: int) -> str:
    if stock <= 0:
        return "Agotado"
    return "Stock Bajo" if stock <= settings.stock_bajo else "Disponible"


@router.get("", response_model=list[KardexRow])
def kardex(db: Session = Depends(get_db)):
    """(Adicional) Kardex con estado visual: Disponible / Stock Bajo / Agotado."""
    filas = db.execute(
        select(VarianteProducto, Producto, Inventario.stock_actual)
        .join(Producto, Producto.id == VarianteProducto.producto_id)
        .join(Inventario, Inventario.variante_id == VarianteProducto.id)
        .order_by(Producto.referencia, VarianteProducto.color, VarianteProducto.talla)).all()
    return [KardexRow(variante_id=v.id, referencia=p.referencia, nombre=p.nombre,
                      categoria=p.categoria, color=v.color, talla=v.talla,
                      stock_actual=s, estado=_estado(s)) for v, p, s in filas]


@router.post("/importar-excel")
async def importar_excel(
        archivo: UploadFile = File(...),
        modo: str = Query("reemplazar", pattern="^(reemplazar|sumar)$"),
        db: Session = Depends(get_db)):
    """Procesa .csv/.xlsx en memoria. Si hay errores reporta la fila exacta y no guarda nada."""
    contenido = await archivo.read()  # en memoria; validacion usa io.BytesIO / io.StringIO
    try:
        df = validacion.leer_archivo(contenido, archivo.filename)
    except validacion.ArchivoInvalido as e:
        raise HTTPException(400, str(e))

    filas, errores = validacion.validar(df)
    if errores:
        raise HTTPException(422, {"mensaje": f"{len(errores)} error(es) en el archivo. "
                                             "No se importó nada.", "errores": errores})
    if not filas:
        raise HTTPException(400, "El archivo no tiene filas de datos")
    try:
        resumen = importador.aplicar(db, filas, modo)
        db.commit()
    except Exception:
        db.rollback()
        raise
    return {"mensaje": "Importación exitosa", "filas_procesadas": len(filas), **resumen}
