from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Inventario, Producto, VarianteProducto
from ..schemas import ProductoOut, VarianteOut

router = APIRouter(prefix="/api/v1/productos", tags=["Productos"])


@router.get("", response_model=list[ProductoOut])
def listar_productos(db: Session = Depends(get_db)):
    """(Adicional al documento) Necesario para que la app móvil elija el producto."""
    return db.scalars(select(Producto).order_by(Producto.referencia)).all()


@router.get("/{producto_id}/variantes", response_model=list[VarianteOut])
def variantes_de_producto(producto_id: int, db: Session = Depends(get_db)):
    """Matriz de variantes: color, talla y stock disponible actual."""
    if db.get(Producto, producto_id) is None:
        raise HTTPException(404, "Producto no encontrado")
    filas = db.execute(
        select(VarianteProducto, Inventario.stock_actual)
        .join(Inventario, Inventario.variante_id == VarianteProducto.id)
        .where(VarianteProducto.producto_id == producto_id)
        .order_by(VarianteProducto.color, VarianteProducto.talla)).all()
    return [VarianteOut(variante_id=v.id, color=v.color, talla=v.talla,
                        stock_disponible=stock) for v, stock in filas]
