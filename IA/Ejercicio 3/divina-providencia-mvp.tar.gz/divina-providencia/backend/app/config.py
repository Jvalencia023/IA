from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg://divina:divina@localhost:5432/divina"
    stock_bajo: int = 5  # <= este valor (y > 0) se muestra como "Stock Bajo"
    cors_origins: str = "http://localhost:5173"

    class Config:
        env_file = ".env"


settings = Settings()
