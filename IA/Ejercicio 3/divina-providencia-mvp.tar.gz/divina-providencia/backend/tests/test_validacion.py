import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import importlib.util

spec = importlib.util.spec_from_file_location(
    "validacion", pathlib.Path(__file__).resolve().parents[1] / "app/services/validacion.py")
v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)

RAIZ = pathlib.Path(__file__).resolve().parents[1]


def test_plantilla_oficial_es_valida():
    df = v.leer_archivo((RAIZ / "plantilla_inventario.csv").read_bytes(), "x.csv")
    filas, errores = v.validar(df)
    assert errores == [] and len(filas) == 4
    assert filas[3]["talla"] == "10"          # talla numérica NO se convierte a número
    assert filas[0]["stock_inicial"] == 12


def test_reporta_fila_exacta():
    csv = ("referencia,nombre_producto,categoria,precio_base,color,talla,stock_inicial\n"
           "REF-1,A,Blusas,45000,Azul,S,12\n"
           "REF-1,A,Blusas,abc,Azul,M,5\n"          # fila 3: precio inválido
           "REF-1,A,Blusas,45000,Azul,S,3\n"        # fila 4: duplicada de la fila 2
           "REF-2,B,Blusas,100,Rojo,M,-4\n"         # fila 5: stock negativo
           "REF-3,C,Blusas,100,Rojo,,4\n").encode()  # fila 6: talla vacía
    _, errores = v.validar(v.leer_archivo(csv, "a.csv"))
    assert [(e["fila"], e["columna"]) for e in errores] == [
        (3, "precio_base"), (4, "referencia/color/talla"),
        (5, "stock_inicial"), (6, "talla")]


def test_punto_y_coma_latin1_y_precio_colombiano():
    csv = ("referencia;nombre_producto;categoria;precio_base;color;talla;stock_inicial\n"
           "REF-9;Camisa Niño;Camisas;45.000;Azul;M;3\n").encode("latin-1")
    filas, errores = v.validar(v.leer_archivo(csv, "a.csv"))
    assert errores == [] and str(filas[0]["precio_base"]) == "45000"


def test_columnas_faltantes():
    try:
        v.leer_archivo(b"referencia,color\nA,B\n", "a.csv")
        assert False
    except v.ArchivoInvalido as e:
        assert "nombre_producto" in str(e)


def test_xlsx_y_producto_inconsistente():
    import io, pandas as pd
    df = pd.DataFrame([["R1","A","Blusas","100","Azul","S","1"],
                       ["R1","A","Blusas","200","Azul","M","1"]], columns=v.COLUMNAS)
    b = io.BytesIO(); df.to_excel(b, index=False)
    _, errores = v.validar(v.leer_archivo(b.getvalue(), "a.xlsx"))
    assert len(errores) == 1 and errores[0]["fila"] == 3
