import { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Alert, FlatList, Linking, Pressable, SafeAreaView, ScrollView, Share, StyleSheet, Text, TextInput, View } from "react-native";
import { StatusBar } from "expo-status-bar";
import { crearPedido, getProductos, getVariantes } from "./api";
import { VENDEDOR_ID } from "./config";

const INDIGO = "#1B2A5C", FUCSIA = "#C2255C";
const cop = (n) => new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(n);

function Boton({ texto, onPress, tipo = "primario", disabled }) {
  return (
    <Pressable onPress={onPress} disabled={disabled} accessibilityRole="button"
      style={[s.btn, tipo === "primario" ? s.btnP : s.btnS, disabled && { opacity: 0.4 }]}>
      <Text style={[s.btnT, tipo !== "primario" && { color: INDIGO }]}>{texto}</Text>
    </Pressable>
  );
}

function Dashboard({ ir }) {
  return (
    <View style={s.centro}>
      <Text style={s.marca}>Divina Providencia</Text>
      <Boton texto="Nuevo pedido" onPress={() => ir("pedido")} />
      <Boton texto="Consultar inventario" tipo="secundario" onPress={() => ir("inventario")} />
    </View>
  );
}

function useProductos() {
  const [productos, setProductos] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => { getProductos().then(setProductos).catch(() => setError("No se pudo conectar con el servidor.")); }, []);
  return { productos, error };
}

function Inventario({ volver }) {
  const { productos, error } = useProductos();
  const [sel, setSel] = useState(null);
  const [vars, setVars] = useState([]);
  useEffect(() => { if (sel) getVariantes(sel.id).then(setVars); }, [sel]);
  const porColor = useMemo(() => vars.reduce((a, v) => ((a[v.color] ||= []).push(v), a), {}), [vars]);

  if (sel) return (
    <ScrollView contentContainerStyle={s.pad}>
      <Boton texto="← Productos" tipo="secundario" onPress={() => { setSel(null); setVars([]); }} />
      <Text style={s.h1}>{sel.referencia} · {sel.nombre}</Text>
      {Object.entries(porColor).map(([color, lista]) => (
        <View key={color} style={s.card}>
          <Text style={s.h2}>{color}</Text>
          <View style={s.fila}>{lista.map((v) => (
            <View key={v.variante_id} style={[s.talla, v.stock_disponible === 0 && { backgroundColor: "#eee" }]}>
              <Text style={s.tallaT}>{v.talla}</Text>
              <Text style={s.disp}>Disp: {v.stock_disponible}</Text>
            </View>))}
          </View>
        </View>))}
    </ScrollView>
  );
  return (
    <View style={{ flex: 1 }}>
      <View style={s.pad}><Boton texto="← Inicio" tipo="secundario" onPress={volver} /></View>
      {error ? <Text style={s.error}>{error}</Text> : !productos ? <ActivityIndicator color={INDIGO} /> : (
        <FlatList data={productos} keyExtractor={(p) => String(p.id)} contentContainerStyle={s.pad}
          ListEmptyComponent={<Text style={s.vacio}>Aún no hay productos cargados.</Text>}
          renderItem={({ item }) => (
            <Pressable style={s.card} onPress={() => setSel(item)}>
              <Text style={s.h2}>{item.referencia} · {item.nombre}</Text>
              <Text style={s.sub}>{item.categoria} · {cop(item.precio_base)}</Text>
            </Pressable>)} />)}
    </View>
  );
}

// ---------- Nuevo pedido ----------
function NuevoPedido({ volver }) {
  const { productos, error } = useProductos();
  const [paso, setPaso] = useState("cliente"); // cliente | producto | matriz | resumen | listo
  const [cliente, setCliente] = useState("");
  const [prod, setProd] = useState(null);
  const [vars, setVars] = useState([]);
  const [color, setColor] = useState(null);
  const [carrito, setCarrito] = useState({}); // variante_id -> {producto, color, talla, cantidad, precio}
  const [enviando, setEnviando] = useState(false);
  const [pedido, setPedido] = useState(null);

  async function elegirProducto(p) {
    setProd(p); setVars([]); setPaso("matriz");
    const v = await getVariantes(p.id);
    setVars(v); setColor(v[0]?.color ?? null);
  }
  const colores = useMemo(() => [...new Set(vars.map((v) => v.color))], [vars]);
  const delColor = vars.filter((v) => v.color === color);

  function cambiar(v, delta) {
    setCarrito((c) => {
      const actual = c[v.variante_id]?.cantidad ?? 0;
      const nueva = Math.max(0, Math.min(v.stock_disponible, actual + delta));
      const { [v.variante_id]: _, ...resto } = c;
      return nueva === 0 ? resto : { ...c, [v.variante_id]: { producto: prod, color: v.color, talla: v.talla, cantidad: nueva, precio: Number(prod.precio_base) } };
    });
  }
  const items = Object.entries(carrito);
  const total = items.reduce((t, [, i]) => t + i.cantidad * i.precio, 0);
  const unidades = items.reduce((t, [, i]) => t + i.cantidad, 0);

  async function enviar() {
    setEnviando(true);
    try {
      const r = await crearPedido({ cliente_nombre: cliente, vendedor_id: VENDEDOR_ID,
        items: items.map(([id, i]) => ({ variante_id: Number(id), cantidad: i.cantidad })) });
      setPedido(r); setPaso("listo");
    } catch (e) {
      const txt = e.detalle ? e.detalle.map((d) => `Variante ${d.variante_id}: pediste ${d.solicitado ?? ""}, disponibles ${d.disponible ?? 0}`).join("\n") : e.mensaje || "No se pudo enviar el pedido.";
      Alert.alert("Pedido rechazado", `${txt}\n\nAjusta las cantidades y vuelve a intentar.`);
    } finally { setEnviando(false); }
  }

  function comprobante() {
    const lineas = items.map(([, i]) => `• ${i.producto.referencia} ${i.producto.nombre} ${i.color} ${i.talla} ×${i.cantidad} = ${cop(i.cantidad * i.precio)}`);
    return `*Divina Providencia* – Pedido #${pedido.id}\nCliente: ${cliente}\n${lineas.join("\n")}\n*Total: ${cop(pedido.total_pedido)}*`;
  }
  async function compartir() {
    const url = `whatsapp://send?text=${encodeURIComponent(comprobante())}`;
    (await Linking.canOpenURL(url)) ? Linking.openURL(url) : Share.share({ message: comprobante() });
  }

  if (paso === "cliente") return (
    <View style={s.pad}>
      <Boton texto="← Inicio" tipo="secundario" onPress={volver} />
      <Text style={s.h1}>¿Para quién es el pedido?</Text>
      <TextInput style={s.input} placeholder="Nombre del cliente o almacén" value={cliente} onChangeText={setCliente} />
      <Boton texto="Elegir productos" disabled={!cliente.trim()} onPress={() => setPaso("producto")} />
    </View>);

  if (paso === "producto") return (
    <View style={{ flex: 1 }}>
      <View style={s.pad}>
        <Text style={s.h1}>Pedido de {cliente}</Text>
        {unidades > 0 && <Boton texto={`Ver resumen (${unidades} prendas · ${cop(total)})`} onPress={() => setPaso("resumen")} />}
      </View>
      {error ? <Text style={s.error}>{error}</Text> : !productos ? <ActivityIndicator color={INDIGO} /> : (
        <FlatList data={productos} keyExtractor={(p) => String(p.id)} contentContainerStyle={s.pad}
          renderItem={({ item }) => (
            <Pressable style={s.card} onPress={() => elegirProducto(item)}>
              <Text style={s.h2}>{item.referencia} · {item.nombre}</Text>
              <Text style={s.sub}>{cop(item.precio_base)}</Text>
            </Pressable>)} />)}
    </View>);

  if (paso === "matriz") return (
    <ScrollView contentContainerStyle={s.pad}>
      <Text style={s.h1}>{prod.referencia} · {prod.nombre}</Text>
      {vars.length === 0 ? <ActivityIndicator color={INDIGO} /> : (<>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
          {colores.map((c) => (
            <Pressable key={c} onPress={() => setColor(c)} style={[s.chip, c === color && s.chipOn]}>
              <Text style={[s.chipT, c === color && { color: "#fff" }]}>{c}</Text>
            </Pressable>))}
        </ScrollView>
        {delColor.map((v) => {
          const cant = carrito[v.variante_id]?.cantidad ?? 0;
          const agotado = v.stock_disponible === 0;
          return (
            <View key={v.variante_id} style={[s.card, s.filaTalla, agotado && { opacity: 0.45 }]}>
              <View>
                <Text style={s.tallaT}>Talla {v.talla}</Text>
                <Text style={s.disp}>{agotado ? "Agotado" : `Disp: ${v.stock_disponible}`}</Text>
              </View>
              <View style={s.stepper}>
                <Pressable style={s.step} onPress={() => cambiar(v, -1)} disabled={agotado}><Text style={s.stepT}>−</Text></Pressable>
                <Text style={s.cant}>{cant}</Text>
                <Pressable style={s.step} onPress={() => cambiar(v, +1)} disabled={agotado}><Text style={s.stepT}>+</Text></Pressable>
              </View>
            </View>);
        })}
      </>)}
      <Boton texto="Listo con este producto" onPress={() => setPaso("producto")} />
    </ScrollView>);

  if (paso === "resumen") return (
    <ScrollView contentContainerStyle={s.pad}>
      <Text style={s.h1}>Resumen · {cliente}</Text>
      {items.map(([id, i]) => (
        <View key={id} style={[s.card, s.filaTalla]}>
          <Text style={{ flex: 1 }}>{i.producto.referencia} {i.producto.nombre}{"\n"}{i.color} · {i.talla} · ×{i.cantidad}</Text>
          <Text style={s.h2}>{cop(i.cantidad * i.precio)}</Text>
        </View>))}
      <Text style={s.total}>{unidades} prendas · {cop(total)}</Text>
      <Boton texto={enviando ? "Enviando…" : "Confirmar pedido"} disabled={enviando || !items.length} onPress={enviar} />
      <Boton texto="Seguir agregando" tipo="secundario" onPress={() => setPaso("producto")} />
    </ScrollView>);

  return (
    <View style={s.centro}>
      <Text style={s.h1}>Pedido #{pedido.id} registrado</Text>
      <Text style={s.sub}>Total {cop(pedido.total_pedido)}</Text>
      <Boton texto="Compartir por WhatsApp" onPress={compartir} />
      <Boton texto="Volver al inicio" tipo="secundario" onPress={volver} />
    </View>);
}

export default function App() {
  const [pantalla, setPantalla] = useState("inicio");
  return (
    <SafeAreaView style={s.root}>
      <StatusBar style="dark" />
      {pantalla === "inicio" && <Dashboard ir={setPantalla} />}
      {pantalla === "inventario" && <Inventario volver={() => setPantalla("inicio")} />}
      {pantalla === "pedido" && <NuevoPedido volver={() => setPantalla("inicio")} />}
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#F4F6FA", paddingTop: 28 },
  pad: { padding: 16, gap: 12 },
  centro: { flex: 1, justifyContent: "center", padding: 24, gap: 16 },
  marca: { fontSize: 30, fontWeight: "700", color: INDIGO, marginBottom: 24 },
  h1: { fontSize: 22, fontWeight: "700", color: INDIGO },
  h2: { fontSize: 16, fontWeight: "700", color: INDIGO },
  sub: { color: "#64748b", marginTop: 2 },
  btn: { minHeight: 60, borderRadius: 12, alignItems: "center", justifyContent: "center", paddingHorizontal: 16 },
  btnP: { backgroundColor: FUCSIA }, btnS: { backgroundColor: "#fff", borderWidth: 1, borderColor: "#cbd5e1" },
  btnT: { color: "#fff", fontSize: 18, fontWeight: "700" },
  card: { backgroundColor: "#fff", borderRadius: 12, padding: 14, borderWidth: 1, borderColor: "#e2e8f0" },
  fila: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 8 },
  talla: { backgroundColor: "#EEF2FF", borderRadius: 10, padding: 10, minWidth: 74, alignItems: "center" },
  tallaT: { fontSize: 18, fontWeight: "700", color: INDIGO }, disp: { fontSize: 13, color: "#475569" },
  filaTalla: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  chip: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 999, backgroundColor: "#fff", borderWidth: 1, borderColor: "#cbd5e1", marginRight: 8 },
  chipOn: { backgroundColor: INDIGO, borderColor: INDIGO }, chipT: { fontWeight: "700", color: INDIGO },
  stepper: { flexDirection: "row", alignItems: "center", gap: 6 },
  step: { width: 52, height: 52, borderRadius: 12, backgroundColor: "#EEF2FF", alignItems: "center", justifyContent: "center" },
  stepT: { fontSize: 28, color: INDIGO, fontWeight: "700" }, cant: { width: 40, textAlign: "center", fontSize: 20, fontWeight: "700" },
  input: { backgroundColor: "#fff", borderWidth: 1, borderColor: "#cbd5e1", borderRadius: 12, padding: 14, fontSize: 18 },
  total: { fontSize: 22, fontWeight: "700", color: INDIGO, textAlign: "right" },
  error: { padding: 16, color: "#991b1b" }, vacio: { textAlign: "center", color: "#64748b", marginTop: 40 },
});
