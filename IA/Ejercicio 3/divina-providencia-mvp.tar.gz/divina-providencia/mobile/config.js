// En un celular físico usa la IP de tu computador en la red, ej: http://192.168.1.20:8000
export const API_URL = "http://10.0.2.2:8000"; // 10.0.2.2 = localhost desde el emulador Android
export const VENDEDOR_ID = 1; // TODO: reemplazar por el usuario autenticado
