import { API_URL } from "./config";

async function req(path, options) {
  const res = await fetch(`${API_URL}/api/v1${path}`, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw { status: res.status, ...(typeof data.detail === "object" ? data.detail : { mensaje: data.detail }) };
  return data;
}
export const getProductos = () => req("/productos");
export const getVariantes = (id) => req(`/productos/${id}/variantes`);
export const crearPedido = (body) =>
  req("/pedidos", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
