const BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";

async function req(path, options) {
  const res = await fetch(`${BASE}/api/v1${path}`, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw { status: res.status, ...(typeof data.detail === "object" ? data.detail : { mensaje: data.detail }) };
  return data;
}

export const getKardex = () => req("/inventario");
export const getPedidos = (estado) => req(`/pedidos${estado ? `?estado=${estado}` : ""}`);
export const cambiarEstado = (id, estado) =>
  req(`/pedidos/${id}/estado`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ estado }) });
export const importarExcel = (archivo, modo = "reemplazar") => {
  const fd = new FormData();
  fd.append("archivo", archivo);
  return req(`/inventario/importar-excel?modo=${modo}`, { method: "POST", body: fd });
};
