import { useEffect, useState } from "react";
import { cambiarEstado, getPedidos } from "./api.js";

const TABS = ["Pendiente", "Despachado"];
const cop = (n) => new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(n);

export default function Pedidos() {
  const [tab, setTab] = useState("Pendiente");
  const [pedidos, setPedidos] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");

  const cargar = () => { setCargando(true); getPedidos(tab).then(setPedidos).catch((e) => setError(e.mensaje)).finally(() => setCargando(false)); };
  useEffect(cargar, [tab]);

  async function accion(id, estado) {
    if (estado === "Cancelado" && !confirm("¿Cancelar este pedido? El stock volverá al inventario.")) return;
    try { await cambiarEstado(id, estado); cargar(); } catch (e) { setError(e.mensaje || "No se pudo actualizar el pedido."); }
  }

  return (
    <section>
      <h1 className="font-display text-3xl text-indigo-dye mb-5">Pedidos</h1>
      <div role="tablist" className="flex gap-2 border-b border-slate-200">
        {TABS.map((t) => (
          <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm -mb-px border-b-2 ${tab === t ? "border-fucsia font-bold text-indigo-dye" : "border-transparent text-slate-500"}`}>
            {t === "Pendiente" ? "Pendientes" : "Despachados"}
          </button>
        ))}
      </div>
      {error && <p role="alert" className="mt-3 rounded-md bg-red-50 px-4 py-3 text-sm text-red-800">{error}</p>}
      {cargando && <p className="mt-6 text-slate-500">Cargando pedidos…</p>}
      {!cargando && pedidos.length === 0 && <p className="mt-6 text-slate-500">No hay pedidos {tab === "Pendiente" ? "pendientes" : "despachados"}.</p>}

      <div className="mt-5 grid gap-4 md:grid-cols-2">
        {pedidos.map((p) => (
          <article key={p.id} className="rounded-lg border border-slate-200 bg-white p-4">
            <header className="flex items-start justify-between">
              <div>
                <h2 className="font-bold text-indigo-dye">Pedido #{p.id} · {p.cliente_nombre}</h2>
                <p className="text-xs text-slate-500">{new Date(p.creado_en).toLocaleString("es-CO")} · Vendedor {p.vendedor_id}</p>
              </div>
              <p className="font-bold tabular-nums">{cop(p.total_pedido)}</p>
            </header>
            <ul className="mt-3 space-y-1 text-sm">
              {p.detalles.map((d, i) => (
                <li key={i} className="flex justify-between"><span>{d.referencia} {d.nombre} · {d.color} · {d.talla}</span><span className="tabular-nums">×{d.cantidad}</span></li>
              ))}
            </ul>
            {p.estado === "Pendiente" && (
              <footer className="mt-4 flex gap-2">
                <button onClick={() => accion(p.id, "Despachado")} className="rounded-md bg-fucsia px-4 py-2 text-sm font-bold text-white hover:brightness-110">Despachar</button>
                <button onClick={() => accion(p.id, "Cancelado")} className="rounded-md border border-slate-300 px-4 py-2 text-sm">Cancelar pedido</button>
              </footer>
            )}
          </article>
        ))}
      </div>
    </section>
  );
}
