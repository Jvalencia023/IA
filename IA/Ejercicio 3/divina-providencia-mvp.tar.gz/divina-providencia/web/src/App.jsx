import { useState } from "react";
import Kardex from "./Kardex.jsx";
import Pedidos from "./Pedidos.jsx";

const SECCIONES = [
  { id: "kardex", nombre: "Kardex de inventario" },
  { id: "pedidos", nombre: "Pedidos" },
];

export default function App() {
  const [vista, setVista] = useState("kardex");
  return (
    <div className="min-h-screen md:flex">
      <aside className="bg-indigo-dye text-white md:w-60 md:min-h-screen px-5 py-5 flex md:block items-center justify-between">
        <div>
          <p className="font-display text-xl leading-tight">Divina<br className="hidden md:block" /> Providencia</p>
          <p className="hidden md:block text-sm text-white/60 mt-1">Panel de bodega</p>
        </div>
        <nav className="flex md:flex-col gap-1 md:mt-10">
          {SECCIONES.map((s) => (
            <button key={s.id} onClick={() => setVista(s.id)}
              className={`text-left px-3 py-2 rounded-md text-sm transition-colors ${vista === s.id ? "bg-white text-indigo-dye font-bold" : "text-white/80 hover:bg-white/10"}`}>
              {s.nombre}
            </button>
          ))}
        </nav>
      </aside>
      <main className="flex-1 p-4 md:p-8 max-w-6xl">{vista === "kardex" ? <Kardex /> : <Pedidos />}</main>
    </div>
  );
}
