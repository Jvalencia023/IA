import { useEffect, useMemo, useState } from "react";
import { getKardex, importarExcel } from "./api.js";

const ICONO = { Disponible: "🟢", "Stock Bajo": "🟠", Agotado: "🔴" };

export default function Kardex() {
  const [filas, setFilas] = useState([]);
  const [busca, setBusca] = useState("");
  const [cargando, setCargando] = useState(true);
  const [arrastrando, setArrastrando] = useState(false);
  const [resultado, setResultado] = useState(null); // {ok, texto, errores}

  const cargar = () => getKardex().then(setFilas).finally(() => setCargando(false));
  useEffect(() => { cargar(); }, []);

  const visibles = useMemo(() => {
    const q = busca.trim().toLowerCase();
    return q ? filas.filter((f) => `${f.referencia} ${f.nombre} ${f.color} ${f.talla}`.toLowerCase().includes(q)) : filas;
  }, [filas, busca]);

  async function subir(archivo) {
    if (!archivo) return;
    setResultado({ ok: null, texto: `Importando ${archivo.name}…` });
    try {
      const r = await importarExcel(archivo);
      setResultado({ ok: true, texto: `${r.filas_procesadas} filas importadas: ${r.productos_creados} productos y ${r.variantes_creadas} variantes nuevas, ${r.variantes_actualizadas} actualizadas.` });
      cargar();
    } catch (e) {
      setResultado({ ok: false, texto: e.mensaje || "No se pudo importar el archivo.", errores: e.errores });
    }
  }

  return (
    <section>
      <h1 className="font-display text-3xl text-indigo-dye mb-5">Kardex de inventario</h1>

      <label
        onDragOver={(e) => { e.preventDefault(); setArrastrando(true); }}
        onDragLeave={() => setArrastrando(false)}
        onDrop={(e) => { e.preventDefault(); setArrastrando(false); subir(e.dataTransfer.files[0]); }}
        className={`block cursor-pointer rounded-lg border-2 border-dashed px-6 py-6 text-center transition-colors ${arrastrando ? "border-fucsia bg-fucsia/5" : "border-slate-300 bg-white"}`}>
        <input type="file" accept=".csv,.xlsx" className="sr-only" onChange={(e) => { subir(e.target.files[0]); e.target.value = ""; }} />
        <span className="font-bold text-indigo-dye">Arrastra aquí tu archivo Excel o CSV</span>
        <span className="block text-sm text-slate-500 mt-1">o haz clic para elegirlo. Columnas: referencia, nombre_producto, categoria, precio_base, color, talla, stock_inicial</span>
      </label>

      {resultado && (
        <div role="status" className={`mt-3 rounded-md px-4 py-3 text-sm ${resultado.ok === false ? "bg-red-50 text-red-800" : resultado.ok ? "bg-green-50 text-green-800" : "bg-slate-100"}`}>
          <p className="font-bold">{resultado.texto}</p>
          {resultado.errores && (
            <ul className="mt-2 space-y-1 max-h-48 overflow-auto">
              {resultado.errores.map((e, i) => (
                <li key={i}>Fila {e.fila} · {e.columna}: {e.error}</li>
              ))}
            </ul>
          )}
        </div>
      )}

      <div className="mt-6 flex items-center justify-between gap-3">
        <input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar por referencia, nombre, color o talla"
          className="w-full max-w-sm rounded-md border border-slate-300 bg-white px-3 py-2 text-sm" />
        <span className="text-sm text-slate-500 whitespace-nowrap">{visibles.length} variantes</span>
      </div>

      <div className="mt-3 overflow-x-auto rounded-lg border border-slate-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-slate-600">
            <tr>{["Referencia", "Producto", "Categoría", "Color", "Talla", "Stock", "Estado"].map((h) => <th key={h} className="px-4 py-2.5 font-medium">{h}</th>)}</tr>
          </thead>
          <tbody>
            {cargando && <tr><td colSpan="7" className="px-4 py-8 text-center text-slate-500">Cargando inventario…</td></tr>}
            {!cargando && visibles.length === 0 && (
              <tr><td colSpan="7" className="px-4 py-8 text-center text-slate-500">No hay inventario todavía. Sube tu primer archivo para empezar.</td></tr>)}
            {visibles.map((f) => (
              <tr key={f.variante_id} className="border-t border-slate-100">
                <td className="px-4 py-2 font-bold text-indigo-dye">{f.referencia}</td>
                <td className="px-4 py-2">{f.nombre}</td>
                <td className="px-4 py-2">{f.categoria}</td>
                <td className="px-4 py-2">{f.color}</td>
                <td className="px-4 py-2">{f.talla}</td>
                <td className="px-4 py-2 tabular-nums">{f.stock_actual}</td>
                <td className="px-4 py-2 whitespace-nowrap">{ICONO[f.estado]} {f.estado}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
